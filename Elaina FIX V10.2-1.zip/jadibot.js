//BY KENZ AHAI
function hi() {
  console.log("Hello World!");
}
hi();